class ApiEndpoints {
  static const String baseUrl = "https://murmuring-caverns-26443.herokuapp.com";
  static const String version = "v1";
}
