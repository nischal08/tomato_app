import 'package:flutter/material.dart';

Color kColorWhiteText = Colors.white;
Color kColorBlackText = Colors.black;
Color kColorLightBrown = Color(0xffCCBBBB);
Color kColorDarkBrown = Color(0xff443734);
Color? kColorLightGrey = Colors.grey[500];
Color? kColorGrey = Colors.grey;
Color? KColorRatingColor= Colors.amber.shade700;