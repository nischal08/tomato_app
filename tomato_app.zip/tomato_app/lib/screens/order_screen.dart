import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:tomato_app/controller/carts.dart';
import 'package:tomato_app/models/order_model.dart';
import 'dart:math';

class OrderScreen extends StatefulWidget {
  static const routeName = "/orders";
  const OrderScreen({Key? key}) : super(key: key);

  @override
  _OrderScreenState createState() => _OrderScreenState();
}

class _OrderScreenState extends State<OrderScreen> {
  var _expanded = false;
  @override
  void initState() {
    _loadingOrderData(context);
    super.initState();
  }

  _loadingOrderData(context) async {
    await Provider.of<Carts>(context, listen: false).fetchOrders(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Your Orders"),
      ),
      body: RefreshIndicator(
        onRefresh: () => _loadingOrderData(context),
        child: Consumer<Carts>(
          builder: (_, order, __) => order.showOrderSpinner
              ? Center(
                  child: CircularProgressIndicator(),
                )
              : Container(
                  height: MediaQuery.of(context).size.height * 0.90,
                  width: double.infinity,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        for (OrderModel item in order.orderItems)
                          _orderItem(item, context, order: order.orderItems),
                        SizedBox(
                          height: 50,
                        )
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }

  AnimatedContainer _orderItem(OrderModel item, BuildContext context,
      {required List<OrderModel> order}) {
    return AnimatedContainer(
      height: _expanded ? min(order.length * 20 + 110, 200) : 120,
      duration: Duration(
        milliseconds: 300,
      ),
      margin: EdgeInsets.symmetric(vertical: 6, horizontal: 20),
      width: double.infinity,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(6.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Column(
                children: [
                  Text(
                    
                    item.orderId,
                    softWrap: false,
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    item.state,
                    style: Theme.of(context)
                        .textTheme
                        .subtitle1!
                        .copyWith(color: Theme.of(context).primaryColor),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    DateFormat.yMMMMEEEEd().add_Hms().format(
                          (DateTime.parse(item.dateCreated)),
                        ),
                    style: Theme.of(context).textTheme.subtitle2,
                  ),
                ],
              ),
              IconButton(
                icon: Icon(Icons.arrow_downward),
                onPressed: () {
                  setState(() {
                    _expanded = !_expanded;
                  });
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
